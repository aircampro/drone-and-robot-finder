# drone2 > 2025-12-07 5:39pm
https://universe.roboflow.com/dronefinder/drone2-epzxe

Provided by a Roboflow user
License: CC BY 4.0

this is a project to try to classify drones robots people and gyro craft for durham uni